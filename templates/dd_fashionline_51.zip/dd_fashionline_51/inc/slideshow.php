﻿<div class="slider">
  <div>
    <img src="<?php echo $this->baseurl ?>/<?php echo $this->params->get('foto1'); ?>" alt="foto1"/>
  </div>
  <div>
    <img src="<?php echo $this->baseurl ?>/<?php echo $this->params->get('foto2'); ?>" alt="foto1"/>
  </div>
  <div>
    <img src="<?php echo $this->baseurl ?>/<?php echo $this->params->get('foto3'); ?>" alt="foto1"/>
  </div>
   <div>
    <img src="<?php echo $this->baseurl ?>/<?php echo $this->params->get('foto4'); ?>" alt="foto1"/>
  </div>
   <div>
    <img src="<?php echo $this->baseurl ?>/<?php echo $this->params->get('foto5'); ?>" alt="foto1"/>
  </div>
</div>


