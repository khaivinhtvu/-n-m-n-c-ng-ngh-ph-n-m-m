﻿<?php
$app = JFactory::getApplication();
$tplparams	= $app->getTemplate(true)->params;
//on off
   $backc	=	htmlspecialchars($this->params->get('backc')); 
	$fc	=	htmlspecialchars($this->params->get('fc')); 
	$tc	=	htmlspecialchars($this->params->get('tc')); 
?>