﻿<?php
$app = JFactory::getApplication();
$tplparams	= $app->getTemplate(true)->params;
//on off
$fbc = htmlspecialchars($tplparams->get('fbc'));
$twc = htmlspecialchars($tplparams->get('twc'));
$gc = htmlspecialchars($tplparams->get('gc'));
$i1 = htmlspecialchars($tplparams->get('i1'));
$i2 = htmlspecialchars($tplparams->get('i2'));
$i3 = htmlspecialchars($tplparams->get('i3'));
$i4 = htmlspecialchars($tplparams->get('i4'));
$i5 = htmlspecialchars($tplparams->get('i5'));
$allicon = htmlspecialchars($tplparams->get('allicon'));
$allbutton = htmlspecialchars($tplparams->get('allbutton'));
$backc = htmlspecialchars($tplparams->get('backc'));


?>